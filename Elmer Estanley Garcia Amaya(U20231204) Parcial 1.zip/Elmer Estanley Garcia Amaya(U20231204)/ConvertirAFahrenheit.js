function convertirACelsius(fahrenheit) {
    const celsius = (fahrenheit - 32) * 5 / 9;
    return celsius;
}

const temperaturaFahrenheit = 85;
const temperaturaCelsius = convertirACelsius(temperaturaFahrenheit);
console.log(`${temperaturaFahrenheit}°F es equivalente a ${temperaturaCelsius.toFixed(2)}°C`);
