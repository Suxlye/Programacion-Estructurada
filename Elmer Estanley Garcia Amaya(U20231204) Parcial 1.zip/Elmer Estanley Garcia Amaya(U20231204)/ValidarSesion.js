function ValidarSesion(usuario, contraseña) {

    const usuarioPredefinido = "admin";
    const contraseñaPredefinida = "1234";

    if (usuario === usuarioPredefinido && contraseña === contraseñaPredefinida) {
        console.log("contraseña del usuario correcta");
    } else {
        console.log("contraseña del usuario incorrecta");
    }
}
ValidarSesion("admin", "1234"); 
