function obtenerNombreMesActual() {
    const fechaActual = new Date();
    const nombresMeses = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];
    
    const mesActual = fechaActual.getMonth();
    return nombresMeses[mesActual];
}

const nombreMesActual = obtenerNombreMesActual();
console.log(`El mes actual es ${nombreMesActual}`);


